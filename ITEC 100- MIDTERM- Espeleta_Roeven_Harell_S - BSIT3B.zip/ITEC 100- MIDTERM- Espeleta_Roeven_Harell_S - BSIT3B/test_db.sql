-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2021 at 08:30 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `acts`
--

CREATE TABLE `acts` (
  `id` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acts`
--

INSERT INTO `acts` (`id`, `username`, `activity`, `time`) VALUES
(16, 'ADMIN', 'LogIn', '2021-04-28 21:15:58'),
(17, 'ADMIN', 'LogOut', '2021-04-28 21:16:52'),
(18, 'ADMIN', 'LogIn', '2021-04-28 21:24:39'),
(19, 'ADMIN', 'LogIn', '2021-04-28 21:24:51'),
(20, 'ADMIN', 'LogOut', '2021-04-28 21:26:30'),
(21, 'ADMIN', 'LogIn', '2021-04-28 21:32:20'),
(22, 'ADMIN', 'LogOut', '2021-04-28 21:35:40'),
(23, 'ADMIN', 'ChangePassword', '2021-04-28 21:47:10'),
(24, 'ADMIN', 'LogIn', '2021-04-28 21:47:46'),
(25, 'ADMIN', 'LogOut', '2021-04-28 21:48:28'),
(26, '@Roeven23', 'LogIn', '2021-04-30 13:51:05'),
(27, '@Roeven23', 'LogOut', '2021-04-30 13:57:28'),
(28, 'nightcarp', 'LogIn', '2021-04-30 15:17:47'),
(29, 'nightcarp', 'LogOut', '2021-04-30 15:17:58'),
(30, 'nightcarp', 'LogIn', '2021-04-30 15:51:17'),
(31, 'nightcarp', 'LogOut', '2021-04-30 15:51:28'),
(32, 'nightcarp', 'ChangePassword', '2021-05-01 00:52:05'),
(33, 'test', 'LogIn', '2021-05-01 00:54:11'),
(34, 'test', 'LogOut', '2021-05-01 00:54:27'),
(35, 'test', 'LogIn', '2021-05-01 00:54:44'),
(36, 'test', 'LogOut', '2021-05-01 00:55:33'),
(37, 'nightcarp', 'LogIn', '2021-05-01 01:16:28'),
(38, 'example', 'LogIn', '2021-05-01 02:07:52'),
(39, 'example', 'LogOut', '2021-05-01 02:08:26'),
(40, 'example', 'ChangePassword', '2021-05-01 02:09:00'),
(41, 'example', 'LogIn', '2021-05-01 02:09:57'),
(42, 'example', 'LogOut', '2021-05-01 02:10:30');

-- --------------------------------------------------------

--
-- Table structure for table `bopols`
--

CREATE TABLE `bopols` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `otp` int(10) NOT NULL,
  `curdate` varchar(50) NOT NULL,
  `endate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bopols`
--

INSERT INTO `bopols` (`id`, `username`, `otp`, `curdate`, `endate`) VALUES
(18, 'ADMIN', 449863, '2021-04-23 01:43:19', '2021-04-23 01:48:19'),
(19, 'ADMIN', 849167, '2021-04-28 21:15:42', '2021-04-28 21:20:42'),
(20, 'ADMIN', 566381, '2021-04-28 21:24:30', '2021-04-28 21:29:30'),
(21, 'ADMIN', 424675, '2021-04-28 21:29:04', '2021-04-28 21:34:04'),
(22, 'ADMIN', 432339, '2021-04-28 21:32:13', '2021-04-28 21:37:13'),
(23, 'ADMIN', 384511, '2021-04-28 21:47:34', '2021-04-28 21:52:34'),
(24, '@Roeven23', 651512, '2021-04-30 13:50:55', '2021-04-30 13:55:55'),
(25, 'nightcarp', 729203, '2021-04-30 15:17:40', '2021-04-30 15:22:40'),
(26, 'nightcarp', 841892, '2021-04-30 15:51:08', '2021-04-30 15:56:08'),
(27, 'test', 151897, '2021-05-01 00:54:04', '2021-05-01 00:59:04'),
(28, 'test', 26986, '2021-05-01 00:54:37', '2021-05-01 00:59:37'),
(29, 'nightcarp', 929337, '2021-05-01 01:15:25', '2021-05-01 01:20:25'),
(30, 'nightcarp', 959403, '2021-05-01 01:16:22', '2021-05-01 01:21:22'),
(31, 'example', 895129, '2021-05-01 02:07:39', '2021-05-01 02:12:39'),
(32, 'example', 840155, '2021-05-01 02:09:49', '2021-05-01 02:14:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(44, 'ADMIN', '@Harell23', 'roevenharellespeleta@gmail.com'),
(45, 'ADMIN23', '@Roeven23', 'roevenharellespeleta@gmail.com'),
(46, '@Roeven23', '@Harell23', 'roevenharellespeleta@gmail.com'),
(47, 'nightcarp', '@Beben23', 'wala@gmail.com'),
(48, 'test', '@Test123', 'try@gmail.com'),
(49, 'Username', '@Username23', 'username@gmail.com'),
(50, 'example', '@Bago123', 'example@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acts`
--
ALTER TABLE `acts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bopols`
--
ALTER TABLE `bopols`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acts`
--
ALTER TABLE `acts`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `bopols`
--
ALTER TABLE `bopols`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
